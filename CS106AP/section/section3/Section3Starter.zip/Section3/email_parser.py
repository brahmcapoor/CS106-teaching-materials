#!/usr/bin/env python3

"""
Section 3: Email parsing!
"""

import sys



def extract_all_hostnames(filename):
    """
    Given a file, parse through all lines in the file and extract all hostnames
    from valid email addresses.
    Then, print sorted the list of all unique hostnames found in the file.
    SOLUTION to emails.txt input:
    ['d.tv', 'gmail.com', 'spam.com', 'stanford.edu', 'yahoo.com']
    """
    pass


def main():
    # This code is provided - just calls extract_all_hostnames()
    # with command line arg.
    args = sys.argv[1:]
    # args[0] is filename
    if len(args) == 1:
        extract_all_hostnames(args[0])
    else:
        print('usage: python3 email_parser.py filename-to-read')


# Python boilerplate
if __name__ == "__main__":
    main()
