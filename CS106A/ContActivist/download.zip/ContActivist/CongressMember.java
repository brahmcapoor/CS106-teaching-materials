/**
 * This class represents a single representative or senator
 * in Congress, and contains information about them including:
 * name, phone number, and optionally an email address.
 */
public class CongressMember {
	
	// TODO: What instance variables do we need?

	public CongressMember(/* TODO: What parameters do we use? */) {

	}
	
	// TODO: What public or private methods do we need?
}
