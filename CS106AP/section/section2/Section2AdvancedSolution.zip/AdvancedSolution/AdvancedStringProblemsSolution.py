


def add_commas_to_numeric_string(digits):
    """
    Implements add_commas_to_numeric_string as specified in the handout.

    >>> add_commas_to_numeric_string('17')
    '17'
    >>> add_commas_to_numeric_string('1001')
    '1,001'
    >>> add_commas_to_numeric_string('12345678')
    '12,345,678'
    >>> add_commas_to_numeric_string('999999999')
    '999,999,999'

    :param digits: a string of digits
    :return: a more legible string of digits, separated by commas
    """

    result = ""
    num_digits = 0
    for char_index in range(len(digits)):
        result = digits[len(digits) - char_index - 1] + result
        num_digits += 1
        if num_digits % 3 == 0 and char_index > 0 and num_digits < len(digits):
            """
            We need to check that 
            a) we've added a multiple of 3 number of digits
            b) we've added at least one digit
            c) there are more digits to add
            """
            result = "," + result
    return result

def remove_all_occurrences(s, to_remove):
    """
    Implements remove_all_occurrences as specified in the handout

    >>> remove_all_occurrences('This is a test', 't')
    'This is a es'
    >>> remove_all_occurrences('Summer is here!', 'e')
    'Summr is hr!'
    >>> remove_all_occurrences('----O----', '-')
    'O'

    :param s: the string to remove characters from
    :param to_remove: the string to be removed (which has a length of 1)
    :return: the filtered string
    """

    result = ""

    for ch in s:
        if ch != to_remove:
            result += ch

    return result

def is_palindrome(s):
    """
    Implements is_palindrome as specified in the handout

    >>> is_palindrome('brahm')
    False
    >>> is_palindrome('maps spam')
    True
    >>> is_palindrome('Maps spam')
    False

    :param s: a string
    :return: whether s is a palindrome
    """

    for i in range(len(s)):
        if s[i] != s[len(s) - 1 - i]:
            return False
    return True


def main():
    print("\nChecking solutions to problems...\n")

    print("Calling add_commas_to_numeric_string('17'): returns " + add_commas_to_numeric_string('17'))
    print("Calling add_commas_to_numeric_string('1001'): returns " + add_commas_to_numeric_string('1001'))
    print("Calling add_commas_to_numeric_string('12345678'): returns " + add_commas_to_numeric_string('12345678'))
    print("Calling add_commas_to_numeric_string('999999999'): returns " + add_commas_to_numeric_string('999999999'))

    print("\n")
    print("Calling remove_all_occurrences('This is a test', 't'): returns " + remove_all_occurrences('This is a test', 't'))
    print("Calling remove_all_occurrences('Summer is here!', 'e'): returns " + remove_all_occurrences('Summer is here!', 'e'))
    print("Calling remove_all_occurrences('----O----', '-'): returns " + remove_all_occurrences('----O----', '-'))

    print("\n")
    print("Calling is_palindrome('brahm'): returns " + str(is_palindrome('brahm')))
    print("Calling is_palindrome('maps spam'): returns " + str(is_palindrome('maps spam')))
    print("Calling is_palindrome('Maps spam'): returns " + str(is_palindrome('Maps spam')))



if __name__ == "__main__":
    main()