#!/usr/bin/env python3

"""
Stanford CS106AP Section 3: Super Email parsing -
realistic, nested loop parsing and lists.
"""

import sys


def email_char(ch):
    """
    Return True if this char is valid to the left or right of '@'
    in an email addr, False otherwise. We'll say the definition
    of a valid email char is:
    Alphabetic, a digit, a dot, a dash, or an underbar.
    >>> email_char('a')
    True
    >>> email_char('9')
    True
    >>> email_char('.')
    True
    >>> email_char('-')
    True
    >>> email_char('_')
    True
    """
    pass


def parse_emails(s):
    """
    Given a string s, parse out and return a list of all the valid
    email addresses from s. Each email address is made of 1 @,
    with one or more email chars to its left and one or more email chars
    (including at least period) to its right.
    >>> parse_emails('xx aa@bb.com 1.2@3.4')
    ['aa@bb.com', '1.2@3.4']
    >>> parse_emails('_@_  aa-bb@TV.org**meh@meh.com')
    ['_@_', 'aa-bb@TV.org', 'meh@meh.com']
    >>> parse_emails('abc @ @ 123')
    ['@', '@']
    >>> parse_emails('')
    []
    """
    pass


def parse_all_emails(filename):
    """
    Given a filename, parse out all the emails,
    and add them to 1 giant list which is returned in
    sorted order. Duplicates are allowed.
    Fun note: Doctests can refer to files in the same folder
    as the code. Here's a test of the file named 'emails.txt'
    >>> parse_all_emails('emails.txt')
    ['@', 'a.7@d_e.org', 'a@a', 'alice@microsoft.com', 'jason@stanford.edu', 'john@example.com']
    """
    pass


def main():
    # This code is provided - just calls parse_all_emails()
    # with command line arg.
    # TODO modify this function to support the -host and -max command line options
    args = sys.argv[1:]
    # args[0] is filename
    if len(args) == 1:
        # print them all out, 1 per line
        emails = parse_all_emails(args[0])
        for email in emails:
            print(email)
    else:
        print('usage: filename-to-read')


# Python boilerplate
if __name__ == '__main__':
    main()
