
def foo(n):
    total = 0
    for i in range(1, n):
        total += 107 % i
    result = total / n
    return int(result * 16)


def make_mystery_list(n):
    lst = []
    for i in range(1, n):
        lst.append(foo(i))
    return lst


def process_lst(lst):
    d = {}
    for e in lst:
        d[e / 3] = e
    return d


def process_dictionary(dictionary):
    total = 0
    for k, v in dictionary.items():
        total += k * v
    print(total)


def main():
    num = foo(8)
    lst = make_mystery_list(num)
    d = process_lst(lst)
    process_dictionary(d)


if __name__ == "__main__":
    main()