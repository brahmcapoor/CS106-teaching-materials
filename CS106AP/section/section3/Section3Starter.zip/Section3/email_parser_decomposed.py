#!/usr/bin/env python3

"""
Section 3: Email parsing!

This is identical to the starter code in email_parser.py,
with an additional function definition to aid you with
decomposing the problem. Trying to come up with another
decomposition for your solution is a great idea, but
this comes with doctests to practice your string parsing.
"""

import sys


def extract_hostname(line):
    """
    Given a line of text, if it contains an email address, return the hostname.
    Each line contains at most one email address, but a line may not contain
    an email address, in which case you should return an empty string: ''.
    An email address is defined as:
    username@host.name, where the hostname is made of alphabetic
    chars and periods. To be valid, a hostname must be at least length 4,
    and contain at least 1 period. We are not checking the validity
    of the hostname in any deeper way than that.
    There are no requirements for the username, and it can be an empty string.
    >>> extract_hostname('Please forward this email to ingrid@stanford.edu for me. Thanks!')
    'stanford.edu'
    >>> extract_hostname('Omg @ye is my favorite!')
    ''
    >>> extract_hostname('Not a host- a@b.c ')
    ''
    >>> extract_hostname('My email address is nick@gmail.com')
    'gmail.com'
    >>> extract_hostname('Hello, world!')
    ''
    >>> extract_hostname('Not happening@')
    ''
    """
    pass


def extract_all_hostnames(filename):
    """
    Given a file, parse through all lines in the file and extract all hostnames
    from valid email addresses.
    Then, print sorted the list of all unique hostnames found in the file.
    SOLUTION to emails.txt input:
    ['d.tv', 'gmail.com', 'spam.com', 'stanford.edu', 'yahoo.com']
    """
    pass


def main():
    # This code is provided - just calls extract_all_hostnames()
    # with command line arg.
    args = sys.argv[1:]
    # args[0] is filename
    if len(args) == 1:
        extract_all_hostnames(args[0])
    else:
        print('usage: python3 email_parser_decomposed.py filename-to-read')


# Python boilerplate
if __name__ == "__main__":
    main()
