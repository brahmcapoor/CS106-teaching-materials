#!/usr/bin/env python3

"""
Stanford CS106AP
Draw TK Section
"""

import sys
import tkinter


def make_canvas(width, height):
    """
    (provided)
    Creates and returns a drawing canvas
    of the given int size with a blue border,
    ready for drawing.
    """
    top = tkinter.Tk()
    top.minsize(width=width + 10, height=height + 10)

    canvas = tkinter.Canvas(top, width=width, height=height)
    canvas.pack()
    canvas.xview_scroll(6, 'units')  # hack so (0, 0) works correctly
    canvas.yview_scroll(6, 'units')

    # draw blue boundaries - sides
    canvas.create_line(0, 0, 0, height - 1, fill='blue')
    canvas.create_line(width - 1, 0, width - 1, height - 1, fill='blue')
    # top to bottom
    canvas.create_line(0, 0, width - 1, 0, fill='blue')
    canvas.create_line(0, height - 1, width - 1, height - 1, fill='blue')
    return canvas


def draw_grid(width, height, n):
    """
    Divide canvas into n vertical and horizontal slices
    (see handout).
    """
    canvas = make_canvas(width, height)

    # your code here




    # required last line puts the canvas-window up on screen
    tkinter.mainloop()


# Default canvas size
WIDTH = 500
HEIGHT = 300

def main():
    # (provided)
    args = sys.argv[1:]

    # args:
    # n               # draws 500x300 with this n
    if len(args) == 1:
        draw_grid(WIDTH, HEIGHT, int(args[0]))

    # args:
    # width height n  # draws custom size grid with n
    if len(args) == 3:
        draw_grid(int(args[0]), int(args[1]), int(args[2]))


if __name__ == '__main__':
    main()

