import sys



def print_most_frequent(filename):
    """
    TODO: Your code here
    """


def main():
    args = sys.argv[1:]
    filename = args[0]
    print_most_frequent(filename)


if __name__ == '__main__':
    main()
