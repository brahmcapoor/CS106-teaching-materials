
def divide_by_2(number):
    number /= 2

def populate_list(lst, n):
    for i in range(n):
        lst.append(2 * i)

def main():
    n = 42
    divide_by_2(n)
    my_favorite_list = []
    populate_list(my_favorite_list, n)
    print(my_favorite_list)

if __name__ == "__main__":
    main()