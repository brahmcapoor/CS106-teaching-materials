"""
calculator.py
-------------
A program to help you get practice with lists and
the main function.
"""

import sys

def main(args):
    # your code here
    pass

if __name__ == "__main__":
    main(sys.argv)